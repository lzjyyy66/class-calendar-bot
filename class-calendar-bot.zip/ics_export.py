# -*- coding: utf-8 -*-
"""导出 iCalendar（.ics）文件，导入手机系统日历即可看到班级日程。

时间统一转成 UTC（``...Z``）输出，避免客户端不认识 ``TZID`` 导致偏移。
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from parser import CN_TZ, CN_TZ_NAME

__all__ = ["to_ics", "write_ics", "digest_text", "format_line"]

_PRODID = "-//ClassCalendarBot//班级日历助手//CN"


def _escape(value: str) -> str:
    return (
        (value or "")
        .replace("\\", "\\\\")
        .replace(";", "\\;")
        .replace(",", "\\,")
        .replace("\r\n", "\\n")
        .replace("\n", "\\n")
    )


def _fold(line: str) -> str:
    """RFC 5545：单行超过 75 字节要折行，续行以空格开头。"""
    raw = line.encode("utf-8")
    if len(raw) <= 75:
        return line
    chunks, current = [], b""
    limit = 75
    for char in line:
        encoded = char.encode("utf-8")
        if len(current) + len(encoded) > limit:
            chunks.append(current)
            current = b""
            limit = 74  # 续行前面有一个空格
        current += encoded
    if current:
        chunks.append(current)
    return "\r\n ".join(chunk.decode("utf-8") for chunk in chunks)


def _utc_stamp(dt: datetime) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=CN_TZ)
    return dt.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _parse_dt(value: str | None):
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value)
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=CN_TZ)


def to_ics(events, calendar_name: str = "班级日程", now: datetime | None = None) -> str:
    """把事件列表渲染成 .ics 文本。"""
    now = now or datetime.now(CN_TZ)
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        f"PRODID:{_PRODID}",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        f"X-WR-CALNAME:{_escape(calendar_name)}",
        f"X-WR-TIMEZONE:{CN_TZ_NAME}",
    ]

    stamp = _utc_stamp(now)
    for event in events:
        start = _parse_dt(event.get("start"))
        if start is None:
            continue
        end = _parse_dt(event.get("end")) or start

        lines.append("BEGIN:VEVENT")
        lines.append(f"UID:{_escape(event.get('id') or '')}@class-calendar-bot")
        lines.append(f"DTSTAMP:{stamp}")

        if event.get("all_day"):
            lines.append(f"DTSTART;VALUE=DATE:{start.strftime('%Y%m%d')}")
            day_end = end.date() if event.get("deadline") else end.date()
            lines.append(f"DTEND;VALUE=DATE:{(day_end + timedelta(days=1)).strftime('%Y%m%d')}")
        else:
            lines.append(f"DTSTART:{_utc_stamp(start)}")
            lines.append(f"DTEND:{_utc_stamp(end)}")

        summary = event.get("title") or "班级日程"
        if event.get("deadline"):
            summary = f"[截止] {summary}"
        lines.append(f"SUMMARY:{_escape(summary)}")

        if event.get("location"):
            lines.append(f"LOCATION:{_escape(event['location'])}")

        description_parts = [f"类型：{event.get('type', '其他')}"]
        if event.get("raw"):
            description_parts.append(f"原文：{event['raw']}")
        source = event.get("source") or {}
        if source.get("sender"):
            description_parts.append(f"发布人：{source['sender']}")
        if source.get("group_name"):
            description_parts.append(f"群：{source['group_name']}")
        lines.append(f"DESCRIPTION:{_escape(chr(10).join(description_parts))}")

        if event.get("deadline"):
            lines.append("STATUS:CONFIRMED")
            lines.append("TRANSP:TRANSPARENT")
        lines.append("END:VEVENT")

    lines.append("END:VCALENDAR")
    return "\r\n".join(_fold(line) for line in lines) + "\r\n"


def write_ics(path: str, events, calendar_name: str = "班级日程", now: datetime | None = None) -> str:
    content = to_ics(events, calendar_name, now)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write(content)
    return content


# --------------------------------------------------------------------------
# 文本摘要（推送到群里用）
# --------------------------------------------------------------------------

_WEEK_CN = ("周一", "周二", "周三", "周四", "周五", "周六", "周日")


def format_line(event: dict, now: datetime | None = None) -> str:
    """把一条事件格式化成一行人类可读文本。"""
    now = now or datetime.now(CN_TZ)
    start = _parse_dt(event.get("start"))
    if start is None:
        return f"· {event.get('title', '')}"

    today = now.date()
    delta = (start.date() - today).days
    if delta == 0:
        day_label = "今天"
    elif delta == 1:
        day_label = "明天"
    elif delta == 2:
        day_label = "后天"
    elif 0 < delta < 7:
        day_label = f"{_WEEK_CN[start.weekday()]}"
    else:
        day_label = start.strftime("%m月%d日")

    if event.get("all_day"):
        when = day_label
    elif event.get("deadline"):
        when = f"{day_label} {start.strftime('%H:%M')} 截止"
    else:
        when = f"{day_label} {start.strftime('%H:%M')}"
        end = _parse_dt(event.get("end"))
        if end and end.date() == start.date() and end > start:
            when += f"-{end.strftime('%H:%M')}"

    parts = [f"· [{when}] {event.get('title', '未命名')}"]
    if event.get("location"):
        parts.append(f"@{event['location']}")
    icon = {"考试": "📝", "作业": "📚", "会议": "🧑‍🏫", "活动": "🎉"}.get(event.get("type", ""), "📌")
    return f"{icon} " + " ".join(parts)


def digest_text(events, days: int = 3, now: datetime | None = None,
                include_overdue: bool = False, title: str | None = None) -> str:
    """生成给群里推送的日程摘要文本。"""
    now = now or datetime.now(CN_TZ)
    header = title or f"【班级日程】未来 {days} 天"

    buckets = {"考试": [], "作业": [], "会议": [], "活动": [], "其他": []}
    overdue = []
    for event in sorted(events, key=lambda e: e.get("start") or ""):
        start = _parse_dt(event.get("start"))
        if start is None:
            continue
        if start < now and not event.get("deadline"):
            overdue.append(event)
            continue
        buckets.setdefault(event.get("type", "其他"), []).append(event)

    lines = [header]
    empty = True
    for label, items in buckets.items():
        if items:
            empty = False
            lines.append(f"\n【{label}】")
            lines.extend(format_line(item, now) for item in items)

    if empty:
        lines.append("\n暂无安排，安心摸鱼 🐟")

    if include_overdue and overdue:
        lines.append(f"\n【已过期 {len(overdue)} 条】")

    lines.append("\n— 由班级日历助手自动整理")
    return "\n".join(lines)
