#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""班级日历助手 —— 主程序。

把 WeLink 群里老师/班委发的通知，自动抽成日历上的日程，并定时把摘要推回群里。

命令行用法::

    python main.py serve                 # 启动 Webhook 服务 + 定时推送（默认）
    python main.py parse "明天下午2点在A301开班会"   # 本地试解析，不写库
    python main.py import-json notices.json      # 批量导入历史消息
    python main.py digest 3              # 打印未来 3 天摘要
    python main.py digest 3 --push       # 打印并推送到群
    python main.py ics                   # 导出 class-calendar.ics
    python main.py stats                 # 看看库里存了多少条
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import time as _time
from datetime import datetime, timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
EXAMPLE_PATH = os.path.join(BASE_DIR, "config.example.json")

if hasattr(sys.stdout, "reconfigure"):  # Windows 控制台中文输出
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except (ValueError, OSError):
        pass

from parser import CN_TZ, parse_event, parse_message  # noqa: E402
import ics_export  # noqa: E402
import welink  # noqa: E402
from store import TaskStore  # noqa: E402

DEFAULT_CONFIG = {
    "welink": {},
    "server": {"host": "0.0.0.0", "port": 8080, "path": "/welink/callback"},
    "push": {"enabled": True, "times": ["08:00"], "digest_days": 3,
             "include_overdue": False, "notify_on_new_event": True},
    "calendar": {"ics_output": "class-calendar.ics", "calendar_name": "班级日程"},
    "store": {"path": "tasks.json", "purge_after_days": 180},
}


# --------------------------------------------------------------------------
# 配置
# --------------------------------------------------------------------------


def _deep_merge(base: dict, override: dict) -> dict:
    result = dict(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def load_config(path: str | None = None) -> dict:
    path = path or CONFIG_PATH
    if not os.path.exists(path):
        if os.path.exists(EXAMPLE_PATH):
            print(f"[config] 没找到 {os.path.basename(path)}，先用 config.example.json 顶着")
            print(f"[config] 正式使用前请执行： cp config.example.json config.json 并填好密钥")
            path = EXAMPLE_PATH
        else:
            return DEFAULT_CONFIG

    with open(path, "r", encoding="utf-8") as fh:
        config = _deep_merge(DEFAULT_CONFIG, json.load(fh))

    # 相对路径统一挂到项目目录下，避免受启动目录影响
    store_path = config["store"]["path"]
    if not os.path.isabs(store_path):
        config["store"]["path"] = os.path.join(BASE_DIR, store_path)
    ics_path = config["calendar"]["ics_output"]
    if not os.path.isabs(ics_path):
        config["calendar"]["ics_output"] = os.path.join(BASE_DIR, ics_path)
    return config


# --------------------------------------------------------------------------
# 核心逻辑
# --------------------------------------------------------------------------


class ClassCalendarBot:
    def __init__(self, config: dict):
        self.config = config
        self.store = TaskStore(config["store"]["path"])

    # ---- 消息处理 ----

    def handle_message(self, text: str, source: dict | None = None):
        """解析一条群消息并入库，返回 (识别到的全部事件, 新增事件)。"""
        events = parse_message(text, source=source)
        added = []
        for event in events:
            ok, _reason = self.store.add(event)
            if ok:
                added.append(event)
        return events, added

    def new_event_reply(self, added) -> str:
        lines = [f"已记入日历 {len(added)} 条："]
        lines.extend(ics_export.format_line(event) for event in added)
        return "\n".join(lines)

    # ---- 摘要推送 ----

    def build_digest(self, days: int | None = None) -> tuple:
        days = days or self.config["push"]["digest_days"]
        events = self.store.upcoming(days)
        text = ics_export.digest_text(
            events, days, include_overdue=self.config["push"]["include_overdue"]
        )
        return events, text

    def push_digest(self, days: int | None = None, dry_run: bool = False) -> str:
        _events, text = self.build_digest(days)
        if dry_run:
            return text
        welink.send_text(text, self.config)
        return text

    # ---- 导出 ----

    def export_ics(self, output: str | None = None) -> str:
        output = output or self.config["calendar"]["ics_output"]
        events = self.store.query()
        ics_export.write_ics(output, events, self.config["calendar"]["calendar_name"])
        return output


# --------------------------------------------------------------------------
# 定时任务
# --------------------------------------------------------------------------


def start_scheduler(bot: ClassCalendarBot) -> threading.Thread:
    """每 20 秒扫一次，到点在群里推摘要；错过超过 1 小时的档期不补推。"""

    def loop():
        fired = set()
        while True:
            now = datetime.now(CN_TZ)
            today = now.strftime("%Y-%m-%d")
            if not bot.config["push"].get("enabled", True):
                _time.sleep(60)
                continue
            for slot in bot.config["push"]["times"]:
                key = f"{today} {slot}"
                if key in fired:
                    continue
                try:
                    hour, minute = (int(x) for x in slot.split(":"))
                    target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
                except (ValueError, TypeError):
                    print(f"[scheduler] 忽略非法时间档：{slot}")
                    fired.add(key)
                    continue
                if now >= target + timedelta(hours=1):
                    fired.add(key)          # 服务启动前就错过了，不补推
                elif now >= target:
                    fired.add(key)
                    try:
                        print(f"[scheduler] {now:%H:%M:%S} 推送 {slot} 档摘要")
                        bot.push_digest()
                    except Exception as exc:  # noqa: BLE001
                        print(f"[scheduler] 推送失败：{exc}")
            fired = {k for k in fired if k.startswith(today)}
            _time.sleep(20)

    thread = threading.Thread(target=loop, name="digest-scheduler", daemon=True)
    thread.start()
    return thread


# --------------------------------------------------------------------------
# HTTP 服务
# --------------------------------------------------------------------------


def create_app(bot: ClassCalendarBot):
    from flask import Flask, Response, jsonify, request

    app = Flask("class-calendar-bot")
    callback_path = bot.config["server"]["path"]

    @app.get("/")
    @app.get("/health")
    def health():
        stats = bot.store.stats()
        return jsonify({"status": "ok", "events": stats["total"], "by_type": stats["by_type"],
                        "server_time": datetime.now(CN_TZ).isoformat()})

    @app.get(callback_path)
    def callback_verify():
        """WeLink 配置回调地址时会发来验证请求，原样回显即可。"""
        return request.args.get("echostr", "ok")

    @app.post(callback_path)
    def callback():
        payload = request.get_json(silent=True) or request.form.to_dict() or {}
        if payload.get("echostr"):
            return payload["echostr"]

        try:
            message = welink.parse_callback(payload, bot.config)
        except PermissionError as exc:
            app.logger.warning("签名校验失败：%s", exc)
            return jsonify({"code": 1, "msg": "signature error"}), 403
        except (ValueError, RuntimeError) as exc:
            app.logger.warning("回调解析失败：%s", exc)
            return jsonify({"code": 2, "msg": str(exc)}), 400

        text = (message.get("text") or "").strip()
        if not text:
            return jsonify({"code": 0, "parsed": 0, "added": 0, "msg": "空消息"})

        events, added = bot.handle_message(text, message)
        if added and bot.config["push"].get("notify_on_new_event", True):
            try:
                welink.send_text(bot.new_event_reply(added), bot.config)
            except Exception as exc:  # noqa: BLE001
                app.logger.warning("回执推送失败：%s", exc)

        return jsonify({"code": 0, "parsed": len(events), "added": len(added),
                        "events": [{"title": e["title"], "start": e["start"]} for e in added]})

    @app.post("/parse")
    def debug_parse():
        """调试用：直接发一段文本看看能解析出什么。"""
        data = request.get_json(silent=True) or {}
        text = data.get("text") or request.form.get("text", "")
        return jsonify({"input": text, "events": parse_message(text)})

    @app.get("/events")
    def list_events():
        try:
            days = int(request.args.get("days", 30))
        except ValueError:
            days = 30
        now = datetime.now(CN_TZ)
        events = bot.store.upcoming(days, now=now)
        return jsonify({"days": days, "count": len(events), "events": events})

    @app.get("/calendar.ics")
    def download_ics():
        content = ics_export.to_ics(bot.store.query(), bot.config["calendar"]["calendar_name"])
        return Response(
            content,
            mimetype="text/calendar",
            headers={"Content-Disposition": "attachment; filename=class-calendar.ics"},
        )

    return app


def run_server(bot: ClassCalendarBot) -> None:
    try:
        import flask  # noqa: F401
    except ImportError:
        print("缺少 Flask，请先安装依赖：pip install -r requirements.txt")
        raise SystemExit(1)

    if bot.config["push"].get("enabled", True):
        start_scheduler(bot)

    server = bot.config["server"]
    app = create_app(bot)
    print("=" * 58)
    print("  班级日历助手 已启动")
    print(f"  监听地址   : http://{server['host']}:{server['port']}")
    print(f"  回调地址   : http://<你的公网地址>:{server['port']}{server['path']}")
    print("  健康检查   : GET  /health")
    print("  日程列表   : GET  /events?days=30")
    print("  日历订阅   : GET  /calendar.ics")
    print(f"  当前事件数 : {bot.store.stats()['total']}")
    print(f"  定时推送   : {', '.join(bot.config['push']['times']) or '关闭'}")
    print("=" * 58)
    app.run(host=server["host"], port=int(server["port"]), debug=False, threaded=True)


# --------------------------------------------------------------------------
# 命令行
# --------------------------------------------------------------------------


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="main.py", description="班级日历助手")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("serve", help="启动 Webhook 服务（默认）")

    p_parse = sub.add_parser("parse", help="本地试解析一段消息")
    p_parse.add_argument("text", nargs="+", help="要解析的消息文本")

    p_import = sub.add_parser("import-json", help="从 JSON 文件批量导入消息")
    p_import.add_argument("path", help="JSON 文件，内容为字符串数组或 {text: [...]}")
    p_import.add_argument("--sender", default="批量导入")

    p_digest = sub.add_parser("digest", help="生成日程摘要")
    p_digest.add_argument("days", nargs="?", type=int, default=3)
    p_digest.add_argument("--push", action="store_true", help="同时推送到群里")

    p_ics = sub.add_parser("ics", help="导出 .ics 日历文件")
    p_ics.add_argument("output", nargs="?", default=None)

    sub.add_parser("stats", help="查看存储统计")
    return parser


def main(argv=None) -> int:
    args = build_arg_parser().parse_args(argv)
    config = load_config()
    bot = ClassCalendarBot(config)
    command = args.command or "serve"

    if command == "serve":
        run_server(bot)
        return 0

    if command == "parse":
        text = " ".join(args.text)
        events = parse_message(text)
        print(f"输入：{text}")
        print(f"识别到 {len(events)} 条日程：")
        print(json.dumps(events, ensure_ascii=False, indent=2))
        return 0

    if command == "import-json":
        with open(args.path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        texts = data.get("text") if isinstance(data, dict) else data
        total_added = 0
        for item in texts or []:
            _events, added = bot.handle_message(item, {"sender": args.sender})
            total_added += len(added)
        print(f"导入完成，新增 {total_added} 条，当前共 {bot.store.stats()['total']} 条")
        return 0

    if command == "digest":
        events, text = bot.build_digest(args.days)
        print(text)
        if args.push:
            welink.send_text(text, config)
            print(f"\n[已推送到群，共 {len(events)} 条]")
        return 0

    if command == "ics":
        path = bot.export_ics(args.output)
        print(f"已导出：{path}")
        return 0

    if command == "stats":
        print(json.dumps(bot.store.stats(), ensure_ascii=False, indent=2))
        return 0

    build_arg_parser().print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
