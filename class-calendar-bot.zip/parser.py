# -*- coding: utf-8 -*-
"""中文通知消息 -> 结构化日程事件 解析器（纯标准库实现）。

设计思路
--------
1. **先抽时间**：日期（绝对日期 > 相对日 > 周几）与时刻（含"上午/晚上""点半"这类口语）。
2. **再判类型**：考试 / 作业 / 会议 / 活动，用关键词加权打分。
3. **最后抠标题**：把已经识别出的日期、时刻、地点片段从原文里删掉，剩下的就是标题。

对不确定的推断会显式打标记（``time_assumed`` / ``all_day``），不偷偷乱猜。

用法::

    >>> from parser import parse_message
    >>> parse_message("明天下午2点在A301开班会")[0]["title"]
    '班会'
"""
from __future__ import annotations

import hashlib
import re
import unicodedata
from datetime import datetime, timedelta, timezone
from datetime import time as _time

__all__ = [
    "CN_TZ",
    "parse_event",
    "parse_message",
    "detect_type",
    "extract_candidates",
]

# 固定东八区，避免 Windows 上缺少 IANA 时区库导致 zoneinfo 不可用
CN_TZ = timezone(timedelta(hours=8), "UTC+8")
CN_TZ_NAME = "Asia/Shanghai"

# --------------------------------------------------------------------------
# 词表
# --------------------------------------------------------------------------

_CN_DIGITS = {
    "零": 0, "〇": 0, "一": 1, "壹": 1, "二": 2, "两": 2, "贰": 2, "三": 3, "叁": 3,
    "四": 4, "肆": 4, "五": 5, "伍": 5, "六": 6, "陆": 6, "七": 7, "柒": 7,
    "八": 8, "捌": 8, "九": 9, "玖": 9,
}
_CN_NUM_CLASS = "零〇一二三四五六七八九十两壹贰叁肆伍陆柒捌玖拾"

#: 类型规则，顺序即优先级（同分时靠前者胜）
TYPE_RULES = (
    ("考试", ("考试", "测验", "小测", "补考", "期末考", "期中考", "四级", "六级", "答辩", "机考", "上机考")),
    ("作业", ("作业", "实验报告", "报告", "论文", "课程设计", "提交", "上交", "交作业", "ddl", "DDL", "截止")),
    ("会议", ("开会", "会议", "例会", "班会", "座谈", "宣讲", "讲座", "培训", "讨论", "分享会", "动员会")),
    ("活动", ("活动", "聚餐", "团建", "比赛", "运动会", "校运会", "晚会", "报名", "体检", "参观",
             "排练", "彩排", "素拓", "体测", "升旗", "志愿者", "社会实践",
             "放假", "停课", "调课", "选课", "开学", "报到")),
)

#: 出现这些词说明是「截止型」日程
DEADLINE_HINTS = ("截止", "ddl", "DDL", "deadline", "之前", "以前", "前交", "前提交", "前完成", "前上传", "前发", "前做完")

_REL_DAYS = {
    "大后天": 3,
    "今天": 0, "今日": 0, "本日": 0, "今早": 0, "今晨": 0, "今晚": 0,
    "明天": 1, "明日": 1, "明早": 1, "明晨": 1, "明晚": 1,
    "后天": 2,
    "昨天": -1, "前天": -2,
}

_WEEKDAY_CHARS = {
    "一": 0, "二": 1, "三": 2, "四": 3, "五": 4, "六": 5, "日": 6, "天": 6,
    "1": 0, "2": 1, "3": 2, "4": 3, "5": 4, "6": 5, "7": 6,
}

_PERIODS = ("凌晨", "早上", "早晨", "上午", "中午", "正午", "下午", "傍晚", "晚上", "夜里", "今晚", "明晚")

# 标题里要剥掉的口水词（反复剥，直到剥不动）
_LEAD_NOISE = (
    "请大家千万记得", "请大家记住", "请大家注意", "请同学们注意", "请大家", "请同学们",
    "大家记得", "大家注意", "记得", "记住", "注意", "提醒一下", "提醒大家", "提醒",
    "别忘了", "别忘记", "不要忘记", "千万不要忘记",
    "通知如下", "通知：", "通知:", "公告：", "公告:", "特此通知",
    "关于", "有关", "有关于",
    "定于", "将于", "拟于", "时间定在", "全天", "当天",
    "前交", "前提交", "前完成", "前上传", "前发", "内交", "内提交", "之前", "以前",
    "交作业", "上交", "提交", "完成",
    "地点在", "地点是",
    "在", "于", "的", "有",
)
_TRAIL_NOISE = ("哦", "呀", "啊", "哈", "～", "~", "！", "!", "？", "?", "。", "，", ",", "；", ";", "、", " ", "\u3000")

# 按类型剥掉领头的动词，例如"开班会" -> "班会"、"交实验报告" -> "实验报告"
_TYPE_LEAD_STRIP = {
    "会议": ("举行的", "召开", "开"),
    "作业": ("提交", "上交", "交", "完成", "写完", "做完"),
}

# --------------------------------------------------------------------------
# 正则
# --------------------------------------------------------------------------

_RE_DATE_FULL = re.compile(
    r"(?:(?P<y>\d{4})\s*[-/.年]\s*)?(?P<m>\d{1,2})\s*[-/.月]\s*(?P<d>\d{1,2})\s*[日号]?"
)
_RE_REL_DAY = re.compile("|".join(sorted(_REL_DAYS, key=len, reverse=True)))
_RE_WEEKDAY = re.compile(r"(?P<which>下{1,3}|这|本|上)?\s*(?:周|星期|礼拜)\s*(?P<wd>[一二三四五六日天1-7])")
_RE_WEEK_ONLY = re.compile(r"(?P<which>下{1,3}|这|本|上)\s*(?:周|星期|礼拜)(?![一二三四五六日天1-7])")

_RE_TIME = re.compile(
    r"(?:(?P<period>凌晨|早上|早晨|上午|中午|正午|下午|傍晚|晚上|夜里|今晚|明晚))?\s*"
    r"(?P<h>\d{1,2}|[" + _CN_NUM_CLASS + r"]{1,3})\s*"
    r"(?P<sep>[:：点时])\s*"
    r"(?:(?P<mi>\d{1,2}|[" + _CN_NUM_CLASS + r"]{1,3})\s*分?|(?P<half>半))?"
)
_RE_TIME_JOIN = re.compile(r"\s*(?:[-~—～至到])\s*")

# 地点：显式写法「地点：xxx」
_RE_LOCATION_LABELED = re.compile(r"(?:地点|地方|位置|教室)\s*[:：是]\s*(?P<loc>[^\s，,。；;！!？?、]{2,24})")
# 地点：自动识别「教学楼B201」「A301」「体育馆」这类
_RE_LOCATION_SHAPE = re.compile(
    r"(?:[\u4e00-\u9fa5]{0,3}"
    r"(?:教学楼|实验楼|图书馆|体育馆|报告厅|会议室|综合楼|办公楼|机房|教室|操场|体育场|食堂|宿舍|礼堂|大厅|球场)"
    r"[A-Za-z]?\d{0,4}"
    r"|[A-Za-z]\d{3,4})"
)

_RE_RANGE_TAIL = re.compile(r"(?:至|到|~|～|—|–|-)\s*$")


# --------------------------------------------------------------------------
# 工具函数
# --------------------------------------------------------------------------


def _norm(text: str) -> str:
    """全角转半角 + 去首尾空白。"""
    return unicodedata.normalize("NFKC", text or "").strip()


def _cn_to_int(token: str):
    """把「三」「十」「二十三」「两」转成 int；失败返回 None。"""
    if token is None:
        return None
    if token.isdigit():
        return int(token)
    if token in _CN_DIGITS:
        return _CN_DIGITS[token]
    if "十" in token:
        left, _, right = token.partition("十")
        tens = _CN_DIGITS[left] if left else 1
        ones = _CN_DIGITS[right] if right else 0
        if tens is None or ones is None:
            return None
        # 支持「十二」「二十」「二十四」
        return tens * 10 + ones
    value = 0
    for ch in token:
        if ch not in _CN_DIGITS:
            return None
        value = value * 10 + _CN_DIGITS[ch]
    return value


def _merge_spans(spans):
    """合并重叠区间，便于一次性从原文里抠掉。"""
    result = []
    for start, end in sorted(set(spans)):
        if result and start <= result[-1][1]:
            result[-1] = (result[-1][0], max(result[-1][1], end))
        else:
            result.append((start, end))
    return result


def _remove_spans(text: str, spans):
    for start, end in reversed(_merge_spans(spans)):
        text = text[:start] + text[end:]
    return text


def detect_type(text: str) -> str:
    """关键词加权打分选类型，长关键词权重更高。"""
    scores = {}
    for name, keywords in TYPE_RULES:
        scores[name] = sum(len(kw) for kw in keywords if kw in text)
    best_name, best_score = "其他", 0
    for name, _ in TYPE_RULES:
        if scores[name] > best_score:
            best_name, best_score = name, scores[name]
    return best_name


def _resolve_weekday(today, which, wd):
    """把「周几 + 修饰词」解析成具体日期。"""
    this_monday = today - timedelta(days=today.weekday())
    if which and "下" in which:
        target = this_monday + timedelta(weeks=which.count("下")) + timedelta(days=wd)
    elif which and "上" in which:
        target = this_monday - timedelta(weeks=which.count("上")) + timedelta(days=wd)
    else:
        # 没写修饰词，或者写了「本周」：取本周；若已过去（严格早于今天）则顺延到下周
        target = this_monday + timedelta(days=wd)
        if not which and target < today:
            target += timedelta(days=7)
    return target


def _apply_period(hour: int, period):
    """把 12 小时制的口语时刻换算成 24 小时制。"""
    if hour is None:
        return None
    if period in ("中午", "正午"):
        return hour + 12 if hour <= 2 else hour
    if period in ("凌晨", "早上", "早晨", "上午"):
        return hour
    if period in ("下午", "傍晚", "晚上", "夜里", "今晚", "明晚"):
        return hour + 12 if hour < 12 else hour
    # 没写时段：1~6 点大概率是下午（校园场景）
    if 1 <= hour <= 6:
        return hour + 12
    return hour


def _extract_date(text: str, today):
    """返回 (date, spans, forced_by_period)。优先级：绝对日期 > 相对日 > 周几。"""
    def _fix_year(month, day, year=None):
        if year is None:
            year = today.year
            try:
                candidate = datetime(year, month, day).date()
            except ValueError:
                return None
            # 「1月5日」在 12 月说，指的是明年
            if (today - candidate).days > 180:
                candidate = datetime(year + 1, month, day).date()
            return candidate
        try:
            return datetime(year, month, day).date()
        except ValueError:
            return None

    match = _RE_DATE_FULL.search(text)
    if match:
        month = int(match.group("m"))
        day = int(match.group("d"))
        year = int(match.group("y")) if match.group("y") else None
        if 1 <= month <= 12 and 1 <= day <= 31:
            resolved = _fix_year(month, day, year)
            if resolved:
                return resolved, [match.span()], False

    for match in _RE_REL_DAY.finditer(text):
        delta = _REL_DAYS[match.group(0)]
        return today + timedelta(days=delta), [match.span()], False

    match = _RE_WEEKDAY.search(text)
    if match:
        wd = _WEEKDAY_CHARS.get(match.group("wd"))
        if wd is not None:
            resolved = _resolve_weekday(today, match.group("which"), wd)
            return resolved, [match.span()], False

    match = _RE_WEEK_ONLY.search(text)
    if match:
        resolved = _resolve_weekday(today, match.group("which"), 0)
        return resolved, [match.span()], False

    return None, [], False


def _extract_time(text: str):
    """返回 (start, end, spans, assumed)。start/end 是 datetime.time 或 None。"""
    match = _RE_TIME.search(text)
    if not match:
        return None, None, [], False

    def _to_time(m):
        hour = _cn_to_int(m.group("h"))
        if hour is None:
            return None
        if m.group("half"):
            minute = 30
        else:
            minute = _cn_to_int(m.group("mi")) if m.group("mi") else 0
            if minute is None:
                return None
        hour = _apply_period(hour, m.group("period"))
        if hour is None or not (0 <= hour <= 23) or not (0 <= minute <= 59):
            return None
        return hour, minute, m.group("period")

    start_info = _to_time(match)
    if start_info is None:
        return None, None, [], False
    start_h, start_m, period = start_info
    assumed = period is None

    start = _time(start_h, start_m)
    spans = [match.span()]

    # 形如 「9:00-11:00」「9点到11点」的结束时刻
    tail = text[match.end():]
    join = _RE_TIME_JOIN.match(tail)
    if join:
        second = _RE_TIME.match(tail, join.end())
        if second:
            end_info = _to_time(second)
            if end_info is not None:
                end_h, end_m, _ = end_info
                # 没有时段前缀时继承开始时间的时段（9:00-11:00 中的 11）
                if second.group("period") is None and end_h < start_h:
                    end_h = _apply_period(end_h, period)
                end = _time(end_h, end_m)
                spans.append((match.end() + join.start(), match.end() + second.end()))
                if end > start:
                    return start, end, spans, assumed

    return start, start, spans, assumed


def _extract_location(text: str):
    match = _RE_LOCATION_LABELED.search(text)
    if match:
        return match.group("loc").strip(), [match.span()]
    match = _RE_LOCATION_SHAPE.search(text)
    if match:
        return match.group(0).strip(), [match.span()]
    return "", []


def _clean_title(text: str, event_type: str) -> str:
    title = text.strip()
    changed = True
    while changed and title:
        changed = False
        for noise in _LEAD_NOISE:
            if title.startswith(noise) and len(title) > len(noise):
                title = title[len(noise):].lstrip("：:=-–—·、,，.")
                changed = True
        for noise in _TYPE_LEAD_STRIP.get(event_type, ()):
            if title.startswith(noise) and len(title) > len(noise):
                title = title[len(noise):]
                changed = True
    title = title.strip("".join(_TRAIL_NOISE)).strip()
    title = re.sub(r"\s{2,}", " ", title)
    title = re.sub(r"^[，,、。.：:；;\-–—]+", "", title).strip()
    title = title.strip("".join(_TRAIL_NOISE)).strip()

    # 只取第一个分句：逗号后面多半是「请各位准时到」这类附注，塞进日历标题反而碍眼
    for clause in re.split(r"[，,。；;！!？?\n]", title):
        clause = clause.strip("".join(_TRAIL_NOISE)).strip()
        if clause:
            title = clause
            break

    if len(title) > 40:
        title = title[:40].rstrip() + "…"
    return title


def _make_id(title: str, start_iso: str, raw: str) -> str:
    digest = hashlib.md5(f"{title}|{start_iso}|{raw}".encode("utf-8")).hexdigest()
    return digest[:12]


# --------------------------------------------------------------------------
# 对外接口
# --------------------------------------------------------------------------


def extract_candidates(text: str, now: datetime | None = None) -> dict:
    """只做识别、不组装事件，方便调试解析效果。"""
    now = now or datetime.now(CN_TZ)
    normalized = _norm(text)
    today = now.date()

    event_date, date_spans, _ = _extract_date(normalized, today)
    start_t, end_t, time_spans, assumed = _extract_time(normalized)

    remainder = _remove_spans(normalized, date_spans + time_spans)
    location, loc_spans = _extract_location(remainder)
    title_pool = _remove_spans(remainder, loc_spans)

    # 类型与截止词只在「标题候选」上判断。
    # 若在原文上判断，「图书馆报告厅」里的"报告"会把一场讲座误判成作业，
    # 而"报告厅"本身已经被地点识别吃掉了。
    event_type = detect_type(title_pool)
    is_deadline = any(hint in title_pool for hint in DEADLINE_HINTS)

    return {
        "normalized": normalized,
        "date": event_date,
        "date_spans": date_spans,
        "start_time": start_t,
        "end_time": end_t,
        "time_spans": time_spans,
        "time_assumed": assumed,
        "location": location,
        "location_spans": loc_spans,
        "type": event_type,
        "is_deadline": is_deadline,
        "remainder": title_pool,
    }


def parse_event(text: str, now: datetime | None = None, source: dict | None = None) -> dict | None:
    """把一条消息解析成事件 dict；识别不出日期则返回 None。"""
    now = now or datetime.now(CN_TZ)
    info = extract_candidates(text, now)

    if info["date"] is None:
        return None

    event_date = info["date"]
    start_t = info["start_time"]
    end_t = info["end_time"]
    event_type = info["type"]
    is_deadline = info["is_deadline"]

    # 置信度闸门：只有「光有日期」的话不算日程，避免把「明天见」「今天天气不错」收进日历
    has_signal = (
        info["start_time"] is not None
        or event_type != "其他"
        or is_deadline
        or bool(info["location"])
    )
    if not has_signal:
        return None

    title = _clean_title(info["remainder"], event_type)
    if not title:
        title = f"{event_type}通知" if event_type != "其他" else "班级日程"

    all_day = False
    deadline = is_deadline or event_type == "作业"
    time_assumed = False

    if start_t is not None:
        start = datetime.combine(event_date, start_t, tzinfo=CN_TZ)
        if end_t is not None and end_t > start_t:
            end = datetime.combine(event_date, end_t, tzinfo=CN_TZ)
        else:
            end = start + timedelta(hours=1)
        time_assumed = info["time_assumed"]
    elif deadline:
        # 「下周一前交作业」这种：默认当天 23:59 截止
        start = datetime.combine(event_date, datetime.min.time(), tzinfo=CN_TZ) + timedelta(hours=23, minutes=59)
        end = start
    else:
        all_day = True
        start = datetime.combine(event_date, datetime.min.time(), tzinfo=CN_TZ)
        end = start + timedelta(hours=23, minutes=59)

    start_iso = start.isoformat()
    event = {
        "id": _make_id(title, start_iso, info["normalized"]),
        "title": title,
        "type": event_type,
        "start": start_iso,
        "end": None if (all_day or deadline) else end.isoformat(),
        "all_day": all_day,
        "deadline": deadline,
        "time_assumed": time_assumed,
        "location": info["location"],
        "raw": info["normalized"],
        "source": source or {},
        "created_at": now.isoformat(),
    }
    return event


def parse_message(text: str, now: datetime | None = None, source: dict | None = None,
                  split_lines: bool = True) -> list:
    """解析一条群消息，可能产出多个事件（按换行拆分成多条通知）。

    识别不出时间的整行会被忽略（群里闲聊不该进日历）。
    """
    now = now or datetime.now(CN_TZ)
    normalized = _norm(text)
    if not normalized:
        return []

    chunks = [c for c in normalized.splitlines() if c.strip()] if split_lines else [normalized]

    events, seen = [], set()
    for chunk in chunks:
        event = parse_event(chunk, now, source)
        if event and event["id"] not in seen:
            seen.add(event["id"])
            events.append(event)
    return events
