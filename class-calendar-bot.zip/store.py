# -*- coding: utf-8 -*-
"""事件存储层：读写 ``tasks.json``，去重、查询、生成摘要。

用 JSON 文件而不是数据库，是为了让整个项目可以零配置跑起来，
并且 ``tasks.json`` 会被 .gitignore 排除（里面是班级真实数据）。
"""
from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime, timedelta

from parser import CN_TZ

__all__ = ["TaskStore"]

_STORE_VERSION = 1


class TaskStore:
    """线程安全的 JSON 事件库（用一把进程内锁即可，够这个场景用）。"""

    def __init__(self, path: str = "tasks.json"):
        self.path = os.path.abspath(path)
        self._data = {"version": _STORE_VERSION, "updated_at": None, "events": []}
        self.load()

    # ---------------- 基础读写 ----------------

    def load(self) -> dict:
        if not os.path.exists(self.path):
            return self._data
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (json.JSONDecodeError, OSError):
            # 文件损坏时不静默覆盖，先备份再重置，避免丢数据
            backup = self.path + ".broken"
            try:
                os.replace(self.path, backup)
            except OSError:
                pass
            print(f"[store] tasks.json 解析失败，已备份到 {backup}，重新开始")
            return self._data

        if isinstance(data, dict) and isinstance(data.get("events"), list):
            self._data = data
            self._data.setdefault("version", _STORE_VERSION)
        return self._data

    def save(self) -> None:
        """原子写：先写临时文件再替换，避免中途崩溃写坏文件。"""
        self._data["updated_at"] = datetime.now(CN_TZ).isoformat()
        directory = os.path.dirname(self.path) or "."
        os.makedirs(directory, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=directory, prefix=".tasks-", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(self._data, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, self.path)
        except Exception:
            if os.path.exists(tmp):
                os.remove(tmp)
            raise

    # ---------------- 增删查改 ----------------

    @property
    def events(self) -> list:
        return self._data["events"]

    def add(self, event: dict) -> tuple[bool, str]:
        """写入事件。返回 (是否新增, 说明)。重复事件（同标题同时间）会被跳过。"""
        for existing in self.events:
            if existing.get("id") == event.get("id"):
                return False, "duplicate"
            # 兜底：标题 + 开始时间一致也算重复（换行/标点差异导致 id 不同时）
            if existing.get("title") == event.get("title") and existing.get("start") == event.get("start"):
                return False, "duplicate"
        self.events.append(event)
        self.events.sort(key=lambda e: e.get("start") or "")
        self.save()
        return True, "added"

    def add_many(self, events) -> list:
        return [self.add(e) for e in events]

    def remove(self, event_id: str) -> bool:
        before = len(self.events)
        self._data["events"] = [e for e in self.events if e.get("id") != event_id]
        if len(self._data["events"]) != before:
            self.save()
            return True
        return False

    def _parse_start(self, event: dict):
        try:
            dt = datetime.fromisoformat(event.get("start") or "")
        except ValueError:
            return None
        return dt if dt.tzinfo else dt.replace(tzinfo=CN_TZ)

    def query(self, start=None, end=None, types=None) -> list:
        """按时间区间（含边界）和类型过滤。"""
        result = []
        for event in self.events:
            dt = self._parse_start(event)
            if dt is None:
                continue
            if start is not None and dt < start:
                continue
            if end is not None and dt > end:
                continue
            if types and event.get("type") not in types:
                continue
            result.append(event)
        return sorted(result, key=lambda e: e["start"])

    def upcoming(self, days: int = 3, now: datetime | None = None) -> list:
        now = now or datetime.now(CN_TZ)
        end = (now + timedelta(days=days)).replace(hour=23, minute=59, second=59)
        return self.query(start=now, end=end)

    def purge_old(self, days: int = 180, now: datetime | None = None) -> int:
        """清掉很久以前的历史事件，防止文件无限膨胀。"""
        now = now or datetime.now(CN_TZ)
        cutoff = now - timedelta(days=days)
        before = len(self.events)
        self._data["events"] = [
            e for e in self.events
            if (self._parse_start(e) or now) >= cutoff
        ]
        removed = before - len(self._data["events"])
        if removed:
            self.save()
        return removed

    def stats(self) -> dict:
        counts = {}
        for event in self.events:
            counts[event.get("type", "其他")] = counts.get(event.get("type", "其他"), 0) + 1
        return {"total": len(self.events), "by_type": counts, "path": self.path}
