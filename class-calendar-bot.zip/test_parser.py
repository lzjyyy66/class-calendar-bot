# -*- coding: utf-8 -*-
"""解析器 + 存储 + 导出的单元测试。

运行： python -m unittest -v test_parser
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import unittest
from datetime import datetime, timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import ics_export  # noqa: E402
from parser import CN_TZ, detect_type, parse_event, parse_message  # noqa: E402
from store import TaskStore  # noqa: E402

# 固定「现在」：2026-10-15 是星期四，方便验证「周三/下周一」这类相对日期
NOW = datetime(2026, 10, 15, 23, 16, tzinfo=CN_TZ)
THURSDAY = datetime(2026, 10, 15).weekday()  # == 3


class TestBaseline(unittest.TestCase):
    def test_now_is_thursday(self):
        """测试用例全部依赖 2026-10-15 是周四，先把这个前提锁住。"""
        self.assertEqual(NOW.weekday(), THURSDAY)
        self.assertEqual(THURSDAY, 3)


class TestTimeExtraction(unittest.TestCase):
    def test_relative_day_with_period_and_location(self):
        event = parse_event("明天下午2点在A301开班会", NOW)
        self.assertIsNotNone(event)
        self.assertEqual(event["start"], "2026-10-16T14:00:00+08:00")
        self.assertEqual(event["location"], "A301")
        self.assertEqual(event["type"], "会议")
        self.assertEqual(event["title"], "班会")
        self.assertFalse(event["all_day"])

    def test_trailing_note_is_dropped_from_title(self):
        """「，请各位准时到」这类附注不该进标题。"""
        event = parse_event("明天下午2点在A301开班会，请各位准时到", NOW)
        self.assertEqual(event["title"], "班会")
        self.assertEqual(event["location"], "A301")

    def test_location_word_does_not_pollute_type(self):
        """「图书馆报告厅」里的"报告"不该把一场讲座判成作业。"""
        event = parse_event("大后天上午10点图书馆报告厅有保研经验分享讲座", NOW)
        self.assertEqual(event["type"], "会议")
        self.assertFalse(event["deadline"])
        self.assertEqual(event["title"], "保研经验分享讲座")
        self.assertEqual(event["location"], "图书馆报告厅")
        self.assertEqual(event["start"], "2026-10-18T10:00:00+08:00")

    def test_school_sports_meet_is_activity_all_day(self):
        event = parse_event("11月2日全天校运会，记得提前找辅导员请假", NOW)
        self.assertEqual(event["type"], "活动")
        self.assertEqual(event["title"], "校运会")
        self.assertTrue(event["all_day"])
        self.assertTrue(event["start"].startswith("2026-11-02T00:00"))

    def test_deadline_defaults_to_2359(self):
        event = parse_event("下周一前交高数作业", NOW)
        self.assertEqual(event["start"], "2026-10-19T23:59:00+08:00")
        self.assertTrue(event["deadline"])
        self.assertEqual(event["type"], "作业")

    def test_absolute_date_with_time_range(self):
        event = parse_event("10月20日上午9:00-11:00英语四级考试，地点：教学楼B201", NOW)
        self.assertEqual(event["start"], "2026-10-20T09:00:00+08:00")
        self.assertEqual(event["end"], "2026-10-20T11:00:00+08:00")
        self.assertEqual(event["type"], "考试")
        self.assertEqual(event["location"], "教学楼B201")
        self.assertEqual(event["title"], "英语四级考试")
        self.assertFalse(event["time_assumed"])

    def test_this_week_friday_evening_half(self):
        event = parse_event("本周五晚上7点半聚餐", NOW)
        self.assertEqual(event["start"], "2026-10-16T19:30:00+08:00")
        self.assertEqual(event["type"], "活动")
        self.assertEqual(event["title"], "聚餐")

    def test_bare_weekday_rolls_forward_when_passed(self):
        """今天周四说「周三」，指的是下周三。"""
        event = parse_event("周三下午3点体测", NOW)
        self.assertEqual(event["start"], "2026-10-21T15:00:00+08:00")
        self.assertEqual(event["title"], "体测")

    def test_tonight_period(self):
        event = parse_event("今晚8点线上班会", NOW)
        self.assertEqual(event["start"], "2026-10-15T20:00:00+08:00")
        self.assertEqual(event["type"], "会议")

    def test_chinese_numeral_hour_assumed_afternoon(self):
        """「两点半」没写上午下午，校园场景按下午 14:30 处理，并打标记。"""
        event = parse_event("明天两点半开会", NOW)
        self.assertEqual(event["start"], "2026-10-16T14:30:00+08:00")
        self.assertTrue(event["time_assumed"])

    def test_explicit_morning_is_not_flipped(self):
        event = parse_event("大后天上午10点讲座", NOW)
        self.assertEqual(event["start"], "2026-10-18T10:00:00+08:00")
        self.assertFalse(event["time_assumed"])
        self.assertEqual(event["type"], "会议")

    def test_year_rollover_for_past_month_day(self):
        """10 月说「1月5日」，应落到明年。"""
        event = parse_event("1月5日交论文", NOW)
        self.assertTrue(event["start"].startswith("2027-01-05"))

    def test_same_year_for_future_month_day(self):
        event = parse_event("12月1日前提交课程设计", NOW)
        self.assertTrue(event["start"].startswith("2026-12-01"))
        self.assertTrue(event["deadline"])
        self.assertEqual(event["title"], "课程设计")


class TestNoiseRejection(unittest.TestCase):
    def test_small_talk_with_day_word_is_rejected(self):
        for text in ("今天天气不错", "明天见", "后天再说吧"):
            with self.subTest(text=text):
                self.assertIsNone(parse_event(text, NOW))

    def test_message_without_date_is_rejected(self):
        self.assertIsNone(parse_event("记得交作业", NOW))
        self.assertIsNone(parse_event("大家注意一下", NOW))

    def test_empty_message(self):
        self.assertEqual(parse_message("", NOW), [])


class TestMultiLine(unittest.TestCase):
    def test_multiline_message_yields_multiple_events(self):
        text = "明天下午2点在A301开班会\n下周三前提交英语论文"
        events = parse_message(text, NOW)
        self.assertEqual(len(events), 2)
        self.assertEqual({e["type"] for e in events}, {"会议", "作业"})

    def test_duplicate_lines_collapse(self):
        text = "明天下午2点开班会\n明天下午2点开班会"
        self.assertEqual(len(parse_message(text, NOW)), 1)

    def test_noise_line_is_skipped_but_others_kept(self):
        text = "今天天气不错\n明天下午2点在A301开班会"
        events = parse_message(text, NOW)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["title"], "班会")


class TestTypeDetection(unittest.TestCase):
    def test_type_keywords(self):
        cases = {
            "下周一英语六级考试": "考试",
            "周五前交实验报告": "作业",
            "明天下午开班会": "会议",
            "周六运动会": "活动",
            "下个月调课安排": "活动",
        }
        for text, expected in cases.items():
            with self.subTest(text=text):
                self.assertEqual(detect_type(text), expected)


class TestStore(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="ccb-test-")
        self.path = os.path.join(self.tmp, "tasks.json")
        self.store = TaskStore(self.path)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_add_and_persist(self):
        event = parse_event("明天下午2点在A301开班会", NOW)
        ok, reason = self.store.add(event)
        self.assertTrue(ok)
        self.assertEqual(reason, "added")
        self.assertTrue(os.path.exists(self.path))

        reloaded = TaskStore(self.path)
        self.assertEqual(len(reloaded.events), 1)
        self.assertEqual(reloaded.events[0]["title"], "班会")

    def test_duplicate_is_skipped(self):
        event = parse_event("明天下午2点在A301开班会", NOW)
        self.store.add(event)
        ok, reason = self.store.add(dict(event))
        self.assertFalse(ok)
        self.assertEqual(reason, "duplicate")
        self.assertEqual(len(self.store.events), 1)

    def test_upcoming_window(self):
        self.store.add(parse_event("明天下午2点开班会", NOW))
        self.store.add(parse_event("12月1日前提交论文", NOW))
        soon = self.store.upcoming(3, now=NOW)
        self.assertEqual(len(soon), 1)
        self.assertEqual(soon[0]["title"], "班会")

    def test_broken_file_is_backed_up_not_lost_silently(self):
        with open(self.path, "w", encoding="utf-8") as fh:
            fh.write("{ this is not json")
        store = TaskStore(self.path)
        self.assertEqual(len(store.events), 0)
        self.assertTrue(os.path.exists(self.path + ".broken"))

    def test_purge_old(self):
        old = parse_event("2026年1月5日开班会", NOW)
        self.store.add(old)
        self.store.add(parse_event("明天下午2点开班会", NOW))
        removed = self.store.purge_old(180, now=NOW)
        self.assertEqual(removed, 1)
        self.assertEqual(len(self.store.events), 1)


class TestIcsExport(unittest.TestCase):
    def setUp(self):
        self.events = [
            parse_event("明天下午2点在A301开班会", NOW),
            parse_event("下周一前交高数作业", NOW),
        ]

    def test_structure_and_crlf(self):
        content = ics_export.to_ics(self.events, "班级日程", now=NOW)
        self.assertTrue(content.startswith("BEGIN:VCALENDAR"))
        self.assertTrue(content.rstrip("\r\n").endswith("END:VCALENDAR"))
        self.assertEqual(content.count("BEGIN:VEVENT"), 2)
        self.assertIn("\r\n", content)
        # 所有行都必须以 \r\n 结束（RFC 5545 硬要求）
        self.assertEqual(content.count("\n"), content.count("\r\n"))

    def test_deadline_marked_in_summary(self):
        content = ics_export.to_ics(self.events, now=NOW)
        self.assertIn("SUMMARY:[截止] 高数作业", content)

    def test_utc_normalisation(self):
        """14:00 北京时间应写成 06:00Z。"""
        content = ics_export.to_ics([self.events[0]], now=NOW)
        self.assertIn("DTSTART:20261016T060000Z", content)

    def test_escaping(self):
        event = dict(self.events[0])
        event["title"] = "开会, 记得带; 材料"
        content = ics_export.to_ics([event], now=NOW)
        self.assertIn("SUMMARY:开会\\, 记得带\\; 材料", content)

    def test_digest_text_contains_groups(self):
        text = ics_export.digest_text(self.events, days=7, now=NOW)
        self.assertIn("【班级日程】", text)
        self.assertIn("班会", text)

    def test_digest_text_when_empty(self):
        text = ics_export.digest_text([], days=3, now=NOW)
        self.assertIn("暂无安排", text)


class TestWelinkSignature(unittest.TestCase):
    def test_signature_roundtrip(self):
        import hashlib

        import welink

        token, timestamp, nonce, encrypt = "tok", "123", "nonce", "abc"
        expected = hashlib.sha1("".join(sorted([token, timestamp, nonce, encrypt])).encode()).hexdigest()
        self.assertTrue(welink.verify_signature(token, expected, timestamp, nonce, encrypt))
        self.assertFalse(welink.verify_signature(token, "deadbeef", timestamp, nonce, encrypt))

    def test_plaintext_callback_is_parsed(self):
        import welink

        payload = {"content": "明天下午2点开班会", "senderName": "王班长",
                   "chatId": "g1", "msgId": "m1"}
        message = welink.parse_callback(payload, {"welink": {"callback_token": ""}})
        self.assertEqual(message["text"], "明天下午2点开班会")
        self.assertEqual(message["sender"], "王班长")
        self.assertEqual(message["group_id"], "g1")


class TestEndToEnd(unittest.TestCase):
    def test_parse_then_store_then_export(self):
        tmp = tempfile.mkdtemp(prefix="ccb-e2e-")
        try:
            store = TaskStore(os.path.join(tmp, "tasks.json"))
            messages = [
                "明天下午2点在A301开班会，请各位准时到",
                "下周一前交高数作业",
                "10月20日上午9:00-11:00 英语四级考试，地点：教学楼B201",
                "本周五晚上7点半班级聚餐",
                "今天天气不错，出来晒晒太阳",
            ]
            added = 0
            for text in messages:
                _events, new = [], []
                for event in parse_message(text, NOW, source={"sender": "测试"}):
                    ok, _ = store.add(event)
                    if ok:
                        new.append(event)
                        added += 1
            self.assertEqual(added, 4)  # 最后一条闲聊必须被丢掉

            ics = ics_export.to_ics(store.query(), now=NOW)
            self.assertEqual(ics.count("BEGIN:VEVENT"), 4)

            digest = ics_export.digest_text(store.upcoming(7, now=NOW), days=7, now=NOW)
            self.assertIn("班会", digest)
            self.assertIn("四级", digest)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    unittest.main(verbosity=2)
