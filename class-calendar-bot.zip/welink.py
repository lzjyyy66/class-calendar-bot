# -*- coding: utf-8 -*-
"""WeLink 对接层：回调验签/解密 + 机器人消息推送。

推送（发）走「群机器人 Webhook」，是明文 JSON，无需密钥，最省事。
接收（收）走「应用回调」，签名校验用 SHA1，消息体是 AES-CBC 加密的，
需要 ``cryptography`` 才能解密；没装的话自动退化为明文模式（仅本地联调用）。
"""
from __future__ import annotations

import base64
import hashlib
import json
import struct
import time

__all__ = [
    "verify_signature",
    "decrypt_message",
    "parse_callback",
    "send_text",
    "send_markdown",
    "send_card",
    "CRYPTO_AVAILABLE",
    "REQUESTS_AVAILABLE",
]

try:  # 可选依赖：只影响「推送」，不影响验签/解密/解析
    import requests

    REQUESTS_AVAILABLE = True
except ImportError:  # pragma: no cover - 取决于环境
    requests = None
    REQUESTS_AVAILABLE = False

try:  # 可选依赖
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

    CRYPTO_AVAILABLE = True
except ImportError:  # pragma: no cover - 取决于环境
    CRYPTO_AVAILABLE = False


# --------------------------------------------------------------------------
# 回调安全
# --------------------------------------------------------------------------


def verify_signature(token: str, signature: str, timestamp: str, nonce: str, encrypt: str) -> bool:
    """WeLink / 企业微信同一套规则：四个值字典序排序后拼字符串做 SHA1。"""
    if not token:
        return True  # 未配置 token 视为不校验（本地联调）
    if not signature:
        return False
    items = sorted([token, timestamp or "", nonce or "", encrypt or ""])
    expect = hashlib.sha1("".join(items).encode("utf-8")).hexdigest()
    return _const_time_eq(expect, signature)


def _const_time_eq(a: str, b: str) -> bool:
    if len(a) != len(b):
        return False
    diff = 0
    for x, y in zip(a, b):
        diff |= ord(x) ^ ord(y)
    return diff == 0


def _aes_key(encoding_aes_key: str) -> bytes:
    key = base64.b64decode(encoding_aes_key + "=")
    if len(key) != 32:
        raise ValueError("encoding_aes_key 长度不对，应为 43 位 Base64 字符")
    return key


def decrypt_message(encoding_aes_key: str, encrypt: str, expected_receiver: str | None = None) -> str:
    """解密回调消息体，返回明文 JSON 字符串。

    明文结构：16 字节随机串 + 4 字节大端长度 + 消息体 + 接收方 ID。
    """
    if not CRYPTO_AVAILABLE:
        raise RuntimeError(
            "未安装 cryptography，无法解密回调消息。"
            "请执行 `pip install cryptography`，或在本地联调时直接发送明文 JSON。"
        )

    key = _aes_key(encoding_aes_key)
    iv = key[:16]
    try:
        raw = base64.b64decode(encrypt)
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"encrypt 不是合法 Base64: {exc}") from exc

    decryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
    plain = decryptor.update(raw) + decryptor.finalize()

    # 去 PKCS#7 填充
    pad = plain[-1]
    if not 1 <= pad <= 32:
        raise ValueError("AES 填充不合法，请检查 encoding_aes_key")
    plain = plain[:-pad]

    body_len = struct.unpack("!I", plain[16:20])[0]
    body = plain[20:20 + body_len].decode("utf-8")
    receiver = plain[20 + body_len:].decode("utf-8")

    if expected_receiver and receiver != expected_receiver:
        raise ValueError(f"接收方 ID 不匹配：期望 {expected_receiver}，实际 {receiver}")
    return body


def parse_callback(payload: dict, config: dict) -> dict | None:
    """把 WeLink 回调 payload 规整成统一的结构。

    返回形如::

        {"text": "...", "sender": "...", "group_id": "...", "msg_id": "..."}
    """
    welink_cfg = (config or {}).get("welink", {}) or {}
    token = welink_cfg.get("callback_token", "")
    aes_key = welink_cfg.get("callback_aes_key", "")

    encrypted = payload.get("encrypt")
    if encrypted:
        if welink_cfg.get("verify_callback_signature", True):
            ok = verify_signature(
                token,
                payload.get("msg_signature") or payload.get("signature", ""),
                payload.get("timestamp", ""),
                payload.get("nonce", ""),
                encrypted,
            )
            if not ok:
                raise PermissionError("回调签名校验失败")
        body = json.loads(decrypt_message(aes_key, encrypted, welink_cfg.get("app_id")))
    else:
        # 明文模式：便于本地用 curl 联调
        body = payload

    text = (
        body.get("content")
        or (body.get("text") or {}).get("content")
        or body.get("message")
        or ""
    )
    return {
        "text": text,
        "sender": body.get("senderName") or body.get("sender") or body.get("from", ""),
        "group_id": body.get("group_id") or body.get("chatId") or body.get("conversationId", ""),
        "group_name": body.get("groupName") or body.get("conversationName", ""),
        "msg_id": body.get("msgId") or body.get("messageId") or "",
        "raw": body,
    }


# --------------------------------------------------------------------------
# 消息推送
# --------------------------------------------------------------------------


def _post(url: str, payload: dict, timeout: int = 10, retries: int = 2) -> dict:
    if not REQUESTS_AVAILABLE:
        raise RuntimeError("缺少 requests，无法推送消息。请执行 `pip install -r requirements.txt`")
    last_error = None
    for attempt in range(retries + 1):
        try:
            response = requests.post(url, json=payload, timeout=timeout)
            response.raise_for_status()
            try:
                return response.json()
            except ValueError:
                return {"code": response.status_code, "raw": response.text}
        except requests.RequestException as exc:
            last_error = exc
            if attempt < retries:
                time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"推送失败（已重试 {retries} 次）：{last_error}")


def _resolve_webhook(config: dict, webhook_url: str | None) -> str:
    url = webhook_url or ((config or {}).get("welink", {}) or {}).get("webhook_url", "")
    if not url or "REPLACE_WITH" in url:
        raise ValueError("还没配置 welink.webhook_url，请先填好 config.json")
    return url


def send_text(content: str, config: dict | None = None, webhook_url: str | None = None) -> dict:
    """发送纯文本消息到群。"""
    url = _resolve_webhook(config or {}, webhook_url)
    return _post(url, {"msgtype": "text", "text": {"content": content}})


def send_markdown(markdown: str, config: dict | None = None, webhook_url: str | None = None) -> dict:
    """发送 Markdown 消息（日程摘要用这个更好看）。"""
    url = _resolve_webhook(config or {}, webhook_url)
    return _post(url, {"msgtype": "markdown", "markdown": {"content": markdown}})


def send_card(title: str, text: str, config: dict | None = None,
              webhook_url: str | None = None, link: str | None = None) -> dict:
    """发送卡片消息。"""
    url = _resolve_webhook(config or {}, webhook_url)
    payload = {"msgtype": "card", "card": {"title": title, "text": text}}
    if link:
        payload["card"]["url"] = link
    return _post(url, payload)
